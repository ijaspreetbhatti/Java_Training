package com.ibm.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Connection dbCon = null;

		try {
//Load the driver
			Class.forName("com.mysql.jdbc.Driver");

//Try establishing the connection
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/ibmDeveloper", "root", "");

			if (dbCon != null) {
//				System.out.println("Successfully connected ...");
				// Create a Statement
				Statement stmt = dbCon.createStatement();
//				new Main().fetchAllDetails(dbCon, stmt);
//				new Main().insertData(dbCon, stmt);
				new Main().insertRuntimeValues(dbCon, stmt);

			} else {
				System.out.println("Some issues while trying to connect...");
			}

		} catch (ClassNotFoundException | SQLException e) {

			System.out.println("Can't load the driver or can't connect: " + e);
		}

	}

	// This fetches all details of user from table
	private void fetchAllDetails(Connection dbCon, Statement stmt) {

		// Write the query to fetch all details from table:user_details
		String fetchQry = "select * from user_details where userId=2";

		try {

			// Execute the query
			ResultSet rs = stmt.executeQuery(fetchQry);

			// Traverse through the results
			while (rs.next()) {
				System.out.print("ID : " + rs.getInt("userId"));
				System.out.println(", Name : " + rs.getString("userName"));
			}
		} catch (SQLException e) {
			System.out.println("Issue while creating the statement : " + e);
		}

	}

	// This inserts a new row in table:user_details
	void insertData(Connection dbCon, Statement stmt) {

		// Write the query to insert data into table: user_details
		String insQry = "insert into user_details(userName, userAddress)" + "values('Neha', 'Kolkatta')";

		// Execute the query
		try {
			if (stmt.executeUpdate(insQry) > 0)
				System.out.println("Successfully inserted a new row");
			else
				System.out.println("Some issues while inserting, please try back later...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	void insertRuntimeValues(Connection dbCon, Statement stmt) {

		// Take the values from runtime
		Scanner scan = new Scanner(System.in);

		System.out.println("Enter you name and address");

		String userName = scan.nextLine();
		String userAddress = scan.nextLine();

		// Write the query for inserting dynamic data into table:user_details
		String insQry = "insert into user_details(userName, userAddress)" + "values" + "('" + userName + "'," + "'"
				+ userAddress + "'" + ")";

		// Execute the query

		try {
			if (stmt.executeUpdate(insQry) > 0)
				System.out.println("Successfully inserted a new row");
			else
				System.out.println("Some issues while inserting, please try back later...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
}
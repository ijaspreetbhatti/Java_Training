package com.ibm.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

public class UsingPrepStmt {

	public static void main(String[] args) {
		Connection dbCon = null;

		try {
//Load the driver
			Class.forName("com.mysql.jdbc.Driver");

//Try establishing the connection
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/ibmDeveloper", "root", "");

			if (dbCon != null) {
//				
				
			
//				new UsingPrepStmt().fetchAllDetails(dbCon);
				new UsingPrepStmt().updateData(dbCon);
			

			} else {
				System.out.println("Some issues while trying to connect...");
			}

		} catch (ClassNotFoundException | SQLException e) {

			System.out.println("Can't load the driver or can't connect: " + e);
		}

	}

	// This fetches all details of user from table
	private void fetchAllDetails(Connection dbCon) {

		// Write the query to fetch all details from table:user_details
		String fetchQry = "select * from user_details where userId = ?";
		
		try {
		// Create a PreparedStatement
		PreparedStatement pstmt = dbCon.prepareStatement(fetchQry);
		
		//Set the value for ?
		pstmt.setInt(1, 3);

		
		//Execute the query
		ResultSet rs = pstmt.executeQuery();

		

			// Traverse through the results
			while (rs.next()) {
				System.out.print("ID : " + rs.getInt("userId"));
				System.out.println(", Name : " + rs.getString("userName"));
			}
		} catch (SQLException e) {
			System.out.println("Issue while creating the statement : " + e);
		}

	}

	// This updates a row in table:user_details
	void updateData(Connection dbCon) {
		
		String upUserName = "Mayank Agarwal";
		String upUserAddress = "Bangalore, India";

		// Write the query to insert data into table: user_details
		String updateQry = "update user_details set userName = ?, userAddress = ? where userId = ?";
		


		try {
			
			// Create a PreparedStatement
			PreparedStatement pstmt = dbCon.prepareStatement(updateQry);
			
			//Set the values for ?
			pstmt.setString(1, upUserName);
			pstmt.setString(2, upUserAddress);
			pstmt.setInt(3, 2);
			
			if (pstmt.executeUpdate() > 0)
				System.out.println("Successfully updated the row");
			else
				System.out.println("Some issues while updating, please try back later...");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	
}
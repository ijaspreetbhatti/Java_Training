package com.ibm.training;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UpdatableResultSetDemo {

	public static void main(String[] args) {
		Connection dbCon = null;

		try {
//Load the driver
			Class.forName("com.mysql.jdbc.Driver");

//Try establishing the connection
			dbCon = DriverManager.getConnection("jdbc:mysql://localhost:3306/ibmDeveloper", "root", "");

			if (dbCon != null) {
				
				new UpdatableResultSetDemo().fetchAndUpdate(dbCon);
			

			} else {
				System.out.println("Some issues while trying to connect...");
			}

		} catch (ClassNotFoundException | SQLException e) {

			System.out.println("Can't load the driver or can't connect: " + e);
		}
	}
	
	//This method fetches and updates at the same time
	private void fetchAndUpdate(Connection dbCon) {
			String qry = "select * from user_details";
			
			try {
				PreparedStatement pstmt = dbCon.prepareStatement(qry, ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_UPDATABLE );
				
				ResultSet rs = pstmt.executeQuery();
				
				while(rs.next()) {
					if(rs.getString("userName").trim().equals("Rupinder Singh Singh")) {
						
						//Update the current row
						rs.updateString(2, "Rupinder");
						
						
						//Commit the changes
						rs.updateRow();
					}
				}
				
				
				
				
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
			
		
	}
}

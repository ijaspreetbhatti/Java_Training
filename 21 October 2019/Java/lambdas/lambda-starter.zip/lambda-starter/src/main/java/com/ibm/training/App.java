package com.ibm.training;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
    	//Inner classes
//        Remote ref = new Remote() {
//        	@Override
//        	public void work() {
//        		System.out.println("Works");
//        	}
//        };
//        ref.work();
        
        //OR java 8 code: lambda expressions
        Remote ref = (a, b) -> System.out.println(a + b);
//        	System.out.println("Still works");
//        	System.out.println("More lines here");
//        	};
        
        
        ref.work(67, 889);
        
        
        
    }
}


@FunctionalInterface
interface Remote{
	void work(int a, int b);
}

package com.ibm.training;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
//        if(new App().add(100, 200) == 300) {
//        	System.out.println("works");
//        }
//        else
//        	System.out.println("Inaccurate result...");
    }
    
    
    int add(int first, int second) {
    	return first + second;
    }
    
    int div(int first, int second) {
    	return first / second;
    }
    
    boolean checkForPalindrome(String value) {
    	if(value.equals("madam")) 
    		return true;
    	else
    		return false;
    	}
    }


interface GreetUser{
	String GREETING = "Hello there :)";
	String getGreeting();
}

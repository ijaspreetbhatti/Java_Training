package com.ibm.training;

import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestInstance.Lifecycle;
import org.junit.jupiter.api.condition.EnabledOnJre;
import org.junit.jupiter.api.condition.EnabledOnOs;
import org.junit.jupiter.api.condition.JRE;
import org.junit.jupiter.api.condition.OS;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.Mock;

import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.atLeast;
import static org.mockito.Mockito.times;

@TestInstance(Lifecycle.PER_CLASS)
public class AppTest 
{

	
	
	
	@Test
	void checkGreeting() {
		//Mock the object
		GreetUser user = mock(GreetUser.class);
		
		when(user.getGreeting()).thenReturn(GreetUser.GREETING);
		
//		System.out.println(user.getGreeting());
		
		assertEquals(GreetUser.GREETING, user.getGreeting());
		
		verify(user, atLeast(2)).getGreeting();
		verify(user, times(1)).getGreeting();
		
		
		
		
	}
	


	
}
